import React, { useState } from "react";

export const Search = ({ searchMovies }) => {
  const [search, setSearch] = useState("");

  const handleChange = (e) => {
    setSearch(() => e.target.value);
  };

  const handleKey = (e) => {
    if (e.key === "Enter") {
      searchMovies(search);
    }
  };

  return (
    <div className="container row">
      <div className="col s12">
        <div className="input-field">
          <input
            placeholder="Search"
            id="search"
            type="text"
            className="validate"
            value={search}
            onChange={handleChange}
            onKeyDown={handleKey}
          />
          <button className="btn" onClick={() => searchMovies(search)}>
            Search
          </button>
        </div>
      </div>
    </div>
  );
};
