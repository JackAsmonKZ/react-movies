import React, { useEffect, useState } from "react";
import { Movies } from "../components/Movies";
import { Preloader } from "../components/Preloader";
import { Search } from "../components/Search";

export const Main = () => {
  const [movies, setMovies] = useState([]);
  const [canNotFind, setCanNotFind] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch("http://www.omdbapi.com/?apikey=ed68169&s=matrix")
      .then((response) => response.json())
      .then((data) => {
        setMovies(data.Search);
        setIsLoading(false);
      });
  }, []);

  const searchMovies = (str) => {
    setIsLoading(true);
    if (str.trim() === "") {
      fetch("http://www.omdbapi.com/?apikey=ed68169&s=matrix")
        .then((response) => response.json())
        .then((data) => {
          setMovies(data.Search);
          setIsLoading(false);
        });
      return;
    }
    fetch(`http://www.omdbapi.com/?apikey=ed68169&s=${str}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.Search === undefined) {
          setCanNotFind(true);
          setIsLoading(false);
        } else {
          setCanNotFind(false);
          setMovies(data.Search);
          setIsLoading(false);
        }
      });
  };

  return (
    <>
      <Search searchMovies={searchMovies} />
      <main className="container content">
        {canNotFind ? (
          <h3>Not found</h3>
        ) : !isLoading ? (
          <Movies movies={movies} />
        ) : (
          <Preloader />
        )}
      </main>
    </>
  );
};
